//
//  HomeView.swift
//  DarkModeInstagram
//
//  Created by Luis Chavez pozo on 7/01/24.
//

import SwiftUI

struct HomeView: View {
    var body: some View {
        ScrollView(.vertical){
            HeaderHomeView(title: "Instagram")
            StoriesView(story: story)
            PostItemView()
            Spacer()
        }.background(.black)
    }
}

#Preview {
    HomeView()
}

let story: [Story] =  [Story( photo: "1", title: "1"),
                       Story( photo: "2", title: "2"),
                       Story( photo: "1", title: "3"),
                       Story( photo: "2", title: "4"),
                       Story( photo: "1", title: "5"),
                       Story( photo: "2", title: "6")]
