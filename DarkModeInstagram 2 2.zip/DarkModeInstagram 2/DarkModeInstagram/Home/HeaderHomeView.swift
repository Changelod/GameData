//
//  SwiftUIView.swift
//  DarkModeInstagram
//
//  Created by Angelo Chavez on 9/01/24.
//

import SwiftUI

struct HeaderHomeView: View {
    
    var title: String
    var body: some View {
        HStack{
            Text(title)
                .foregroundColor(.white)
                .bold()
            Spacer()
            Image(systemName: "lock")
                .imageScale(.large)
                .foregroundStyle(.white)
        }
        .padding(.horizontal)
        .background(.black) 
    }
}

#Preview {
    HeaderHomeView(title: "Instagram")
}
