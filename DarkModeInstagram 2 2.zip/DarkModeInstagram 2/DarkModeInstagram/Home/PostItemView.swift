//
//  PostView.swift
//  DarkModeInstagram
//
//  Created by Angelo Chavez on 9/01/24.
//

import SwiftUI

struct PostItemView: View {
    @State private var comentario: String = ""
    var body: some View {
        ForEach(story) { story in
            VStack(alignment: .leading){
                HStack(alignment: .top){
                    Image(profile.photo)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 60)
                    
                    VStack(alignment: .leading){
                        
                        Text("\(profile.name)")
                            .foregroundColor(.white)
                            .bold()
                        Text("\(profile.description)")
                            .foregroundColor(.white)
                            .bold()
                        
                    }
                    Spacer()
                    Image(systemName: "equal")
                        .imageScale(.large)
                        .foregroundStyle(.white)

                }.padding()
                Image("1")
                    .resizable()
                    .scaledToFit()
                HStack{
                    Image(systemName: "heart")
                        .imageScale(.large)
                        .foregroundStyle(.white)
                    Image(systemName: "bubble.right")
                        .imageScale(.large)
                        .foregroundStyle(.white)
                    Image(systemName: "paperplane")
                        .imageScale(.large)
                        .foregroundStyle(.white)
                    Spacer()
                    Image(systemName: "bookmark")
                        .imageScale(.large)
                        .foregroundStyle(.white)
                }.padding(.horizontal, 2)
                HStack{
                    
                    Text("\(profile.followerCount)")
                        .foregroundColor(.white)
                        .bold()
                    Text("Followers")
                        .foregroundColor(.white)
                        .bold()
                    
                }.padding(.horizontal, 2)
                Text(profile.description)
                    .foregroundColor(.white)
                    .padding(.horizontal, 2)
                HStack{
                    Image(profile.photo)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 40)
                    TextField("Escribe tu comentario aquí", text: $comentario)
                        .foregroundColor(.white)
                        .bold()
                }.padding(.horizontal, 2)
                Text("Hace 4 dias")
                    .foregroundColor(.gray)
                    .bold()
                    .padding(.horizontal, 2)
            }
            
            .background(.black)
            
        }

    }
}

#Preview {
    PostItemView()
}
