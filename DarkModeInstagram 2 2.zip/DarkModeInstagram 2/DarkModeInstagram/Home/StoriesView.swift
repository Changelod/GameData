//
//  Stories.swift
//  DarkModeInstagram
//
//  Created by Angelo Chavez on 9/01/24.
//

import SwiftUI

struct StoriesView: View {
    let story: [Story]
    var body: some View {
        ScrollView(.horizontal) {
            
            HStack (alignment: .top){
                VStack{
                    Image(profile.photo)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 65)
                    Text("Tu historia")
                        .foregroundColor(.white)
                        .bold()
                }
                
                ForEach(story) { story in
                    VStack{
                        Image(story.photo)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 65)
                            .clipShape(Circle())
                            .overlay(
                                Circle()
                                    .stroke(LinearGradient(gradient: .init(colors: [Color.purple,Color.red, Color.orange]), startPoint: .topTrailing, endPoint: .topLeading), lineWidth: 4)

                            )
                            .overlay(Circle().stroke(Color.black, lineWidth: 1)) // Borde adicional (puedes personalizarlo)
                           

                        Text(story.title)
                            .foregroundColor(.white)
                    }
                }
            }
            .padding(.vertical , 4)
            .padding(.horizontal, 5)
            .background(.black)
            
        }
    }
}

#Preview {
    StoriesView(story: [Story( photo: "1", title: "1"),
                    Story( photo: "2", title: "2"),
                    Story( photo: "1", title: "3"),
                    Story( photo: "2", title: "4"),
                    Story( photo: "1", title: "5"),
                    Story( photo: "2", title: "6")])
}

struct Story: Identifiable{
    var id = UUID()
    let photo: String
    let title : String
}
