//
//  DarkModeInstagramApp.swift
//  DarkModeInstagram
//
//  Created by Luis Chavez pozo on 7/01/24.
//

import SwiftUI

@main
struct DarkModeInstagramApp: App {
    var body: some Scene {
        WindowGroup {
            AppTabNavigationView()
        }
    }
}
