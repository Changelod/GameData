//
//  PostContainer.swift
//  DarkModeInstagram
//
//  Created by Luis Chavez pozo on 7/01/24.
//

import SwiftUI

struct PostBar: View {
    var body: some View {
        HStack{
            Image(systemName: "square.grid.3x3")
                .imageScale(.large)
                .foregroundStyle(.white)
            Spacer()
            Image(systemName: "play.fill")
                .imageScale(.large)
                .foregroundStyle(.white)
            Spacer()
            Image(systemName: "photo.fill")
                .imageScale(.large)
                .foregroundStyle(.white)
            
            
        }
        .frame(maxWidth: /*@START_MENU_TOKEN@*/.infinity/*@END_MENU_TOKEN@*/ , maxHeight: 40)
        .padding(.horizontal, 40 )
        .background(.black)
        
    }
    
}

#Preview {
    PostBar()
}
