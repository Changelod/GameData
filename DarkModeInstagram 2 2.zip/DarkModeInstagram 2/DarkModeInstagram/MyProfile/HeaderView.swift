//
//  HeaderView.swift
//  DarkModeInstagram
//
//  Created by Luis Chavez pozo on 7/01/24.
//

import SwiftUI

struct HeaderView: View {
    
    var title: String
    
    var body: some View {
        HStack{
            Image(systemName: "lock")
                .imageScale(.large)
                .foregroundStyle(.white)
            Text(title)
                .foregroundColor(.white)
                .bold()
            Spacer()
            Image(systemName: "lock")
                .imageScale(.large)
                .foregroundStyle(.white)
            Image(systemName: "lock")
                .imageScale(.large)
                .foregroundStyle(.white)
        }.background(.black)
    }
}

#Preview {
    HeaderView(title: "Angelo")
}


