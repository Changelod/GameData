//
//  PostGrid.swift
//  DarkModeInstagram
//
//  Created by Luis Chavez pozo on 7/01/24.
//

import SwiftUI

struct PostGrid: View {
    var body: some View {
        let columns = [GridItem(.flexible()) , GridItem(.flexible()), GridItem(.flexible()) ]
             
        VStack{
            PostBar()
                LazyVGrid(columns : columns){
                    Image("1")
                    Image("2")
                    Image("1")
                    Image("2")
                    Image("1")
                    Image("2")
                    Image("1")
                    Image("2")
                    Image("1")
                    Image("2")
                    Image("1")
                    Image("2")
                    Image("1")
                    Image("2")
                    Image("1")
                    Image("2")
                    Image("1")
                    Image("2")
                    Image("1")
                    Image("2")
                    
                }
        }
    }
}

#Preview {
    PostGrid()
}
