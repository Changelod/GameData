//
//  ContentView.swift
//  DarkModeInstagram
//
//  Created by Luis Chavez pozo on 7/01/24.
//

import SwiftUI

struct MyProfile: View {
    var body: some View {
        ScrollView{
            VStack(alignment: .leading) {
                HeaderView(title: "Angelo")
                ProfileInformationView(profile: profile)
                HighlightsView(highlight: highlights)
                PostGrid()
               
            }
            .frame(maxWidth: /*@START_MENU_TOKEN@*/.infinity/*@END_MENU_TOKEN@*/)
            .padding(.horizontal)
           
        } .background(.black)
       
    }
       
}

#Preview {
    MyProfile()
}

//Datos de prueba

let profile = ProfileInformation(photo: "perfil", name: "MonNom", description: "La description de mon profil", publicationCount: 153, followerCount: 209, viewCount: 100)

let highlights: [HighLights] =  [HighLights( photo: "1", title: "1"),
                              HighLights( photo: "2", title: "2"),
                              HighLights( photo: "1", title: "3"),
                              HighLights( photo: "2", title: "4"),
                              HighLights( photo: "1", title: "5"),
                              HighLights( photo: "2", title: "6")]
