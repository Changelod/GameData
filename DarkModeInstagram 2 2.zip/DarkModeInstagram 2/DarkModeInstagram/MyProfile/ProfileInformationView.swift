//
//  ProfileInformationView.swift
//  DarkModeInstagram
//
//  Created by Luis Chavez pozo on 7/01/24.
//

import SwiftUI

struct ProfileInformationView: View {
    let profile: ProfileInformation
    
    var body: some View {
        VStack(alignment: .leading){
            HStack(){
                Image(profile.photo)
                
                    .resizable()
                    .scaledToFit()
                    .frame(width: 100)
                Spacer()
                VStack{
                    
                    Text("\(profile.publicationCount)")
                        .foregroundColor(.white)
                        .bold()
                    Text("Publications")
                        .foregroundColor(.white)
                        .bold()
                    
                }
                VStack{
                    
                    Text("\(profile.followerCount)")
                        .foregroundColor(.white)
                        .bold()
                    Text("Followers")
                        .foregroundColor(.white)
                        .bold()
                    
                }
                VStack{
                    
                    Text("\(profile.viewCount)")
                        .foregroundColor(.white)
                        .bold()
                    Text("Views")
                        .foregroundColor(.white)
                        .bold()
                    
                }
            }
            
            VStack(alignment: .leading){
                Text(profile.name)
                    .foregroundColor(.white)
                    .bold()
                Text(profile.description)
                    .foregroundColor(.white)
            }
            HStack{
                Button("Modifier le profil"){
                    
                }.padding()
                    .frame(maxWidth: .infinity, maxHeight: 32)
                .foregroundColor(.white)
                .bold()
                .background(.gray)
                
                Spacer()
                Image(systemName: "lock")
                    .frame(maxHeight: 32)
                    .padding(.horizontal)
                    .foregroundColor(.white)
                    .bold()
                    .background(.gray)
                    
                
            }.padding(.vertical)
        }.background(.black)
    }
    
}

#Preview {
    ProfileInformationView(profile: profile)
}

struct ProfileInformation {
    let photo: String
    let name: String
    let description: String
    let publicationCount: Int
    let followerCount: Int
    let viewCount: Int
    
}

