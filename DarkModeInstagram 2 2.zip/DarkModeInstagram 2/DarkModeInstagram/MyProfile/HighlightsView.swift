//
//  Story.swift
//  DarkModeInstagram
//
//  Created by Luis Chavez pozo on 7/01/24.
//

import SwiftUI

struct HighlightsView: View {
    let highlight: [HighLights]
    var body: some View {
        
        ScrollView(.horizontal) {
            HStack (alignment: .top){
                
                ForEach(highlight) { highlight in
                    VStack{
                        Image(highlight.photo)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 65)
                            .clipShape(Circle())
                            .overlay(
                                Circle()
                                    .stroke(Color.gray, lineWidth: 3) // Ajusta el color y el ancho del borde
                            )
                            .overlay(Circle().stroke(Color.black, lineWidth: 2)) // Borde adicional (puedes personalizarlo)

                        Text(highlight.title)
                            .foregroundColor(.white)
                    }
                }
                VStack{
                    Circle()
                        .frame(width: 65)
                        .foregroundColor(.gray)
                    Text("New")
                        .foregroundColor(.white)
                }
            }
            .padding(.vertical , 6)
            .background(.black)
            
        }

    }
}
#Preview {
    HighlightsView(highlight: [HighLights( photo: "1", title: "1"),
                    HighLights( photo: "2", title: "2"),
                    HighLights( photo: "1", title: "3"),
                    HighLights( photo: "2", title: "4"),
                    HighLights( photo: "1", title: "5"),
                    HighLights( photo: "2", title: "6")])
}

struct HighLights: Identifiable{
    var id = UUID()
    let photo: String
    let title : String
}


